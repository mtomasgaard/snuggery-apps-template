// The galaxy scale, in kiloparsecs, in astropy's Galactocentric frame (v4.0: the Galactic center at
// the origin, the Sun at x = −8.122 kpc, z = +20.8 pc). `root.matrix` is the `to_icrs` matrix from
// galaxy.json, so everything here lands in the same ICRS heliocentric space as the stars.
//
// There is no photograph of our galaxy from outside, and nothing here pretends to be one: the
// measured clusters, satellites, streams and young-star maps, two spiral-arm fits (masers and
// Cepheids, which disagree by about 0.9 kpc near the Sun) and a faint glow of a disk-and-bar mass
// model, each layer labeled as what it is (NOTES.md has the sources).

import * as THREE from '../vendor/three.module.js';
import { glowPointsMaterial, planeMaterial, ribbonMaterial, thickLineMaterial, ThickLine, hexToRgb01 } from './gfx.js';
import { KPC_AU } from './util.js';
import { PLATE } from './plate.js';
import { buildGalaxyData } from './galaxydata.js';

const C = PLATE.cat;

export class Galaxy {
  constructor({ g, tex }) {
    this.g = g;
    this.data = buildGalaxyData(g);           // the frame and the flags, as tools/test_galaxy.mjs checks them
    this.root = new THREE.Group();
    this.root.name = 'galaxy';
    this.root.matrixAutoUpdate = false;
    this.root.matrix.set(...this.data.toIcrsMatrix);
    this.sun = g.frame.sun_kpc;

    const layer = (name) => { const o = new THREE.Group(); o.name = name; this.root.add(o); return o; };
    this.L = {
      model: layer('model'), young: layer('young'), reid: layer('reid'), drimmel: layer('drimmel'),
      grid: layer('grid'), streams: layer('streams'), globulars: layer('globulars'), satellites: layer('satellites'), marks: layer('marks'),
    };

    // ---- disk and bar model glow: a few stacked planes give it a little thickness edge-on
    if (g.model && tex.model) {
      const e = g.model.extent_kpc;               // [xmin, xmax, ymin, ymax]
      const w = e[1] - e[0], h = e[3] - e[2];
      const hz = (g.model.scale_heights_kpc && (g.model.scale_heights_kpc.thin || g.model.scale_heights_kpc.thin_disk)) || 0.3;
      const levels = [[0, 0.5], [0.45, 0.22], [-0.45, 0.22], [1.0, 0.08], [-1.0, 0.08]];
      for (const [k, a] of levels) {
        const mat = planeMaterial(tex.model, { tint: [1.0, 0.86, 0.66], opacity: a });
        const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
        p.position.set((e[0] + e[1]) / 2, (e[2] + e[3]) / 2, k * hz);
        p.frustumCulled = false; p.renderOrder = 0;
        this.L.model.add(p);
      }
    }
    // ---- Gaia young-star overdensity maps
    if (g.young && tex.young) {
      for (const [key, t] of Object.entries(tex.young)) {
        const meta = g.young.files[key];
        const e = meta.extent_kpc || g.young.extent_kpc;
        const enc = meta.encoding;           // overdensity = lo + code/255·(hi − lo); light only above 0
        t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; t.needsUpdate = true;
        const mat = planeMaterial(t, { tint: [0.32, 0.58, 1.0], opacity: 0.8, alphaFromMap: true, zero: -enc.lo / (enc.hi - enc.lo), gamma: 1.4 });
        const p = new THREE.Mesh(new THREE.PlaneGeometry(e[1] - e[0], e[3] - e[2]), mat);
        p.position.set((e[0] + e[1]) / 2, (e[2] + e[3]) / 2, meta.z_kpc || 0);
        p.frustumCulled = false; p.renderOrder = 1; p.userData.key = key;
        this.L.young.add(p);
      }
      // Two maps, two layers. On by default: Poggio+2021's upper-main-sequence map, the smoother one.
      // The Gaia DR3 OB map reaches as far but is streaked along lines of sight by distance errors.
    }

    // ---- spiral-arm fits
    // The Reid fits' band: SpiralMap draws its edges at (R_kink ± width/2)·exp(…), so at radius R the
    // band is width·R/R_kink across. Drawn with a soft falloff to its edges.
    const ribbon = (pts, widthKpc, rKink, color, opacity) => {
      const n = pts.length;
      const pos = new Float32Array(n * 2 * 3), uv = new Float32Array(n * 2 * 2), idx = [];
      let len = 0; const cum = [0];
      for (let i = 1; i < n; i++) { len += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); cum.push(len); }
      for (let i = 0; i < n; i++) {
        const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
        let tx = b[0] - a[0], ty = b[1] - a[1]; const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
        const half = 0.5 * widthKpc * Math.hypot(pts[i][0], pts[i][1]) / rKink;
        const nx = -ty * half, ny = tx * half;
        pos.set([pts[i][0] + nx, pts[i][1] + ny, pts[i][2]], i * 6);
        pos.set([pts[i][0] - nx, pts[i][1] - ny, pts[i][2]], i * 6 + 3);
        uv.set([cum[i] / (len || 1), 1, cum[i] / (len || 1), 0], i * 4);
        if (i < n - 1) idx.push(i * 2, i * 2 + 1, i * 2 + 2, i * 2 + 1, i * 2 + 3, i * 2 + 2);
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
      geo.setIndex(idx);
      const mesh = new THREE.Mesh(geo, ribbonMaterial(color, opacity));
      mesh.frustumCulled = false; mesh.renderOrder = 2;
      return mesh;
    };
    const centerline = (pts, color, alpha, dashed, width = 1.6) => {
      const c = hexToRgb01(color);
      const l = ThickLine.from(pts, (i) => [c[0], c[1], c[2], dashed ? (i % 6 < 3 ? alpha : 0) : alpha],
        thickLineMaterial({ width, depthTest: false })).mesh;
      l.renderOrder = 3;
      return l;
    };
    this.armLabels = [];
    for (const a of g.arms_reid2019 || []) {
      this.L.reid.add(ribbon(a.points, a.width_kpc, a.r_kink_kpc, C.reid.color, PLATE.reidBand));
      this.L.reid.add(centerline(a.points, C.reid.color, PLATE.reidLine, false));   // over its own band and the glow
      this.armLabels.push({ layer: 'reid', name: a.name, p: a.points[Math.floor(a.points.length * 0.55)], color: C.reid.color, src: a });
    }
    for (const a of g.arms_drimmel2024 || []) {
      this.L.drimmel.add(centerline(a.points, C.drimmel.color, C.drimmel.alpha, true));
      this.armLabels.push({ layer: 'drimmel', name: a.name, p: a.points[Math.floor(a.points.length * 0.5)], color: C.drimmel.color, src: a });
    }

    // ---- a reference grid: rings every 5 kpc around the center (an aid, not data)
    const ringMat = thickLineMaterial({ width: 1, depthTest: false });
    for (let r = 5; r <= 25; r += 5) {
      const N = 256, p = new Float32Array((N + 1) * 3);
      for (let i = 0; i <= N; i++) { const t = (i / N) * 2 * Math.PI; p.set([r * Math.cos(t), r * Math.sin(t), 0], i * 3); }
      const l = ThickLine.from(p, [...hexToRgb01(PLATE.neutral), PLATE.alpha.grid], ringMat).mesh; l.renderOrder = 1;
      this.L.grid.add(l);
    }

    // ---- stellar streams
    this.streams = g.streams || [];
    this.streams.forEach((s, i) => {
      const approx = this.data.streamApproximate(i);   // not a measured distance track, or a constructed great circle
      // Faint: a hundred of them cross the whole view, and they are the least certain thing here.
      const l = centerline(s.points, C.streams.color, approx ? PLATE.streamsApprox : C.streams.alpha, approx, 1.1);
      this.L.streams.add(l);
    });

    // ---- globular clusters and satellite galaxies
    const points = (list, color, sizeOf, layerGroup) => {
      const n = list.length, p = new Float32Array(n * 3), c = new Float32Array(n * 3), s = new Float32Array(n);
      const cc = hexToRgb01(color);
      list.forEach((o, i) => { p.set(o.xyz, i * 3); c.set(cc, i * 3); s[i] = sizeOf(o); });
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(p, 3));
      geo.setAttribute('acolor', new THREE.BufferAttribute(c, 3));
      geo.setAttribute('asize', new THREE.BufferAttribute(s, 1));
      const mat = glowPointsMaterial({ opacity: 1, sharp: 0.2 }); mat.depthTest = false;
      const pts = new THREE.Points(geo, mat);
      pts.frustumCulled = false; pts.renderOrder = 4;
      layerGroup.add(pts);
      return pts;
    };
    const magSize = (lo, hi) => (o) => Number.isFinite(o.mv) ? Math.max(lo, Math.min(hi, lo + (-(o.mv) - 4) * 0.55)) : lo;
    this.globulars = g.globulars || [];
    this.satellites = g.satellites || [];
    points(this.globulars, C.globulars.color, magSize(2.4, 6.5), this.L.globulars);
    points(this.satellites, C.satellites.color, magSize(3.0, 12), this.L.satellites);

    // ---- the Sun and the center
    const marks = [{ xyz: this.sun, c: PLATE.marks.sun, s: 7 }, { xyz: [0, 0, 0], c: PLATE.marks.center, s: 6 }];
    this.markPts = points(marks.map((m) => ({ xyz: m.xyz, mv: NaN })), PLATE.marks.sun, () => 7, this.L.marks);
    const mc = this.markPts.geometry.attributes.acolor.array;
    marks.forEach((m, i) => mc.set(hexToRgb01(m.c), i * 3));
  }

  // Galactocentric kpc → ICRS heliocentric AU (float64), for labels and picking.
  toAU(p, out = [0, 0, 0]) {
    const q = this.data.toIcrs(p, this._q || (this._q = new Float64Array(3)));
    out[0] = q[0] * KPC_AU; out[1] = q[1] * KPC_AU; out[2] = q[2] * KPC_AU;
    return out;
  }

  // `dSunKpc` = the camera's distance from the Sun in kpc.
  update(dSunKpc, pxRatio, layers) {
    // Everything here fades in once the camera is far enough out for the galaxy to be the subject.
    const a = Math.min(1, Math.max(0, (Math.log10(Math.max(dSunKpc, 1e-9)) + 0.7) / 0.9));   // 0.2 kpc → 1.6 kpc
    const b = Math.min(1, Math.max(0, (Math.log10(Math.max(dSunKpc, 1e-9)) + 1.3) / 0.8));   // halo objects a bit earlier
    this.fade = a;
    const set = (grp, on, alpha) => {
      grp.visible = on && alpha > 0.01;
      grp.traverse((o) => {
        const m = o.material, u = m && m.uniforms;
        // The base opacity is kept on the material, which several objects may share (the grid rings).
        if (u && u.uOpacity) { if (m.userData.base == null) m.userData.base = u.uOpacity.value; u.uOpacity.value = m.userData.base * alpha; }
        else if (m && m.isLineBasicMaterial) { m.opacity = alpha; }
        if (u && u.uPx) u.uPx.value = pxRatio;
      });
    };
    // The model glow is a face-on density map: from a few kpc of the Sun it fills the whole view with
    // the model's local disk and washes out the measured young-star maps, so it gives way close in.
    const near = Math.min(1, Math.max(0, (Math.log10(Math.max(dSunKpc, 1e-9)) - 0.3) / 0.9));   // 2 kpc → 16 kpc
    set(this.L.model, layers.model, a * (0.15 + 0.85 * near));
    set(this.L.young, layers.young || layers.youngOB, a);
    for (const p of this.L.young.children) p.visible = p.userData.key === 'gaiadr3_ob' ? !!layers.youngOB : !!layers.young;
    set(this.L.reid, layers.reid, a);
    set(this.L.drimmel, layers.drimmel, a);
    set(this.L.grid, layers.grid, a);
    set(this.L.streams, layers.streams, b);
    set(this.L.globulars, layers.globulars, b);
    set(this.L.satellites, layers.satellites, b);
    set(this.L.marks, true, a);
  }
}
